#include<iostream>
using namespace std;

int main ()
{
    int arr[5], a, i, max, min;
    cout << "Please enter your size of the array : ";
    cin >> a;
    cout << "Please enter your elements of the array : ";
    
    for (i = 0; i < a; i++)
        cin >> arr[i];
        
    max = arr[0];
    
    for (i = 0; i < a; i++)
    {
        if (max < arr[i])
            max = arr[i];
    }
    min = arr[0];
    
    for (i = 0; i < a; i++)
    {
        if (min > arr[i])
            min = arr[i];
    }
    cout << "Your Maximum  element is : " << max<<endl;
    cout << "Your Minimum  element is : " << min;
    return 0;
}

