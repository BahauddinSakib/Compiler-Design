#include <iostream>
using namespace std;
 
int main()
{
 
 
    int First_name,Last_name;
 
    cout<<"Please enter first name size :"<<endl;
    cin>>First_name;
    char arr[First_name];
 
        cout<<"Please enter your first name char by char :"<<endl;
 
    for(int i=0;i<First_name;i++)
    {
        cin>>arr[i];
    }
    cout<<"Please enter last name size :"<<endl;
    cin>>Last_name;
    char arr1[Last_name];
    cout<<"Please enter your last name char by char :"<<endl;
 
     for(int i=0;i<Last_name;i++)
    {
        cin>>arr1[i];
     }
 
    string Full_name = string(arr, First_name) + " " + string(arr1, Last_name);
 
         cout<<"Your name is = "<<Full_name<<endl;
    return 0;
 
}
 