#include <iostream>
using namespace std;

int main()
{
    int a, i,n;
    float num[50], sum=0.0, avg;

    cout << "Enter the numbers of input: ";
    cin >> n;

    while (n > 100 || n <= 0)
    {
        cout << "Enter your numbers : ";
        cin >> n;
    }

    for(i = 0; i < n; ++i)
    {
        cout << i + 1 << " Enter number: ";
        cin >> num[i];
        sum += num[i];
    }

    avg = sum / n;
    cout << "Average is : " << avg;

    return 0;
}
