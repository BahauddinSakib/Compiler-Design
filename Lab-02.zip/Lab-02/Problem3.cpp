#include <iostream>
using namespace std;

int isComment(string str);

int main()
   {
    string input;

    cout << "Please enter your string: "<<endl<<endl;
    getline(cin, input);

    cout << "Input String is : " << input << endl<<endl;

    if (isComment(input) == 1)
    {
        cout << "This  is a single-lined comment" << endl;
    }
    else if (isComment(input) == 2)
    {
        cout << "This is a multi-lined comment" << endl;
    }
    else
    {
        cout << "This is not a comment" << endl;
    }

    //return 0;
}

int isComment(string str) {
    int n = str.length();

    if (str.find("//") != string::npos)
    {
        return 1;
    }

    if (n >= 4 & str.substr(0, 2) == "/*" & str.substr(n - 2, 2) == "*/") {
        return 2;
    }

    return 0;
}



