#include <iostream>
using namespace std;

bool isNumeric(string str);

int main() {
   string str;
   cout << "Please enter a string: ";
   cin >> str;
   if (isNumeric(str))
      cout << "This is a Numeric Constant" << endl;
   else
      cout << "This is not a Numeric Constant";
}

bool isNumeric(string str) {
    for (int i = 0; i < str.length(); i++) {
        if (!isdigit(str[i])& str[i]!='.')
        {
            return false;
        }
    }
    return true;
}


