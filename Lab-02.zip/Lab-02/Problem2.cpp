#include <iostream>
using namespace std;

int main()
{
    string n;
    cout << "Please enter a input: "<<endl;
    getline(cin, n);

    cout << "Operators : ";
    bool found = false;

    for (char ch : n) {
        if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '%' || ch == '=') {

            cout << ch << " ";
            found = true;
        }
    }

    if (!found) {
        cout << "Not found";
    }

    return 0;
}
